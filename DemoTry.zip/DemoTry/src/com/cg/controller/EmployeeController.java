package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.IEmployeeService;

@RestController
@EnableAutoConfiguration
@ComponentScan("com.cg.service")
public class EmployeeController {
	
	@Autowired
	private IEmployeeService empService;


    /*@ReuestMapping("/hello")
    String home() {
        return "Hello World!";
    }
	*/
	@RequestMapping("/hello")
	//@GetMapping("/hello")
    Employee home() {
        return empService.getDetails();
	}
	

    public static void main(String[] args) throws Exception {
        SpringApplication.run(EmployeeController.class, args);
    }

}