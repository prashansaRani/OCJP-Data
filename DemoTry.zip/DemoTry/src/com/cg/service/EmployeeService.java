package com.cg.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.dto.Employee;

@Service
public class EmployeeService implements IEmployeeService{
	

	@Override
	public Employee getDetails() {
		
		
		Employee emp = new Employee();
		emp.setEmpId(1001);
		emp.setEmpName("prashansa");
		emp.setEmpAddress("Banda");
		
		return emp;
		// TODO Auto-generated method stub
	  
	}

}
